﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Battleship
{
    static void Main()
    {
        int Sx1 = int.Parse(Console.ReadLine());
        int Sy1 = int.Parse(Console.ReadLine());
        int Sx2 = int.Parse(Console.ReadLine());
        int Sy2 = int.Parse(Console.ReadLine());
        int H = int.Parse(Console.ReadLine());
        int Cx1 = int.Parse(Console.ReadLine());
        int Cy1 = int.Parse(Console.ReadLine());
        int Cx2 = int.Parse(Console.ReadLine());
        int Cy2 = int.Parse(Console.ReadLine());
        int Cx3 = int.Parse(Console.ReadLine());
        int Cy3 = int.Parse(Console.ReadLine());
        int Sy1N = Sy1 - H;
        int Sy2N = Sy2 - H;
        int Cy1N = Cy1 - H;
        int Cy2N = Cy2 - H;
        int Cy3N = Cy3 - H;
        if (Sx1 > Sx2)
        {
            int temp = Sx1;
            Sx1 = Sx2;
            Sx2 = temp;
        }
        if (Sy1N > Sy2N)
        {
            int temp = Sy1N;
            Sy1N = Sy2N;
            Sy2N = temp;
        }
        int sum = 0;
        if (((Cx1 > Sx2) || (Cx1 < Sx1)) || ((Math.Abs(Cy1N) < Sy1N) || (Math.Abs(Cy1N) > Sy2N)))
        {
            sum = 0;
        }
        else
        {
            if (((Cx1 < Sx2) && (Cx1 > Sx1)) && ((Math.Abs(Cy1N) > Sy1N) && (Math.Abs(Cy1N) < Sy2N)))
            {
                sum = 100;
            }
            else
            {
                if (((Cx1 == Sx1) || (Cx1 == Sx2)) && ((Math.Abs(Cy1N) == Sy1N) || (Math.Abs(Cy1N) == Sy2N)))
                {
                    sum = 25;
                }
                else
                {
                    sum = 50;
                }
            }
            
        }
        if (((Cx2 > Sx2) || (Cx2 < Sx1)) || ((Math.Abs(Cy2N) < Sy1N) || (Math.Abs(Cy2N) > Sy2N)))
        {
            sum += 0;
        }
        else
        {
            if (((Cx2 < Sx2) && (Cx2 > Sx1)) && ((Math.Abs(Cy2N) > Sy1N) && (Math.Abs(Cy2N) < Sy2N)))
            {
                sum += 100;
            }
            else
            {
                if (((Cx2 == Sx1) || (Cx2 == Sx2)) && ((Math.Abs(Cy2N) == Sy1N) || (Math.Abs(Cy2N) == Sy2N)))
                {
                    sum += 25;
                }
                else
                {
                    sum += 50;
                }
            }

        }
        if (((Cx3 > Sx2) || (Cx3 < Sx1)) || ((Math.Abs(Cy3N) < Sy1N) || (Math.Abs(Cy3N) > Sy2N)))
        {
            sum += 0;
        }
        else
        {
            if (((Cx3 < Sx2) && (Cx3 > Sx1)) && ((Math.Abs(Cy3N) > Sy1N) && (Math.Abs(Cy3N) < Sy2N)))
            {
                sum += 100;
            }
            else
            {
                if (((Cx3 == Sx1) || (Cx3 == Sx2)) && ((Math.Abs(Cy3N) == Sy1N) || (Math.Abs(Cy3N) == Sy2N)))
                {
                    sum += 25;
                }
                else
                {
                    sum += 50;
                }
            }

        }
        
        //if (((Cx1 > Sx2) || (Cx1 < Sx1)) || ((Math.Abs(Cy1N) < Sy1N) || (Math.Abs(Cy1N) > Sy2N)))
        //{
        //    sum = 0;
        //}
        //if (((Cx1 == Sx1) || (Cx1 == Sx2)) && ((Math.Abs(Cy1N) == Sy1N) || (Math.Abs(Cy1N) == Sy2N)))
        //{
        //    sum = 25;
        //}
        //if ((((Cx1 == Sx1) || (Cx1 == Sx2)) && ((Math.Abs(Cy1N) > Sy1N) || (Math.Abs(Cy1N) < Sy2N))) || (((Cx1 < Sx1) || (Cx1 > Sx2)) && ((Math.Abs(Cy1N) == Sy1N) || (Math.Abs(Cy1N) == Sy2N))))
        //{
        //    sum = 50;
        //}
        //if ((Cx1 > Sx1) && (Cx1 < Sx2) && (Math.Abs(Cy1N) > Sy1N) && (Math.Abs(Cy1N) < Sy2N))
        //{
        //    sum = 100;
        //}
        //
        //if (((Cx2 > Sx2) || (Cx2 < Sx1)) || ((Math.Abs(Cy2N) < Sy1N) || (Math.Abs(Cy2N) > Sy2N)))
        //{
        //    sum += 0;
        //}
        //if (((Cx2 == Sx1) || (Cx2 == Sx2)) && ((Math.Abs(Cy2N) == Sy1N) || (Math.Abs(Cy2N) == Sy2N)))
        //{
        //    sum += 25;
        //}
        //if ((((Cx2 == Sx1) || (Cx2 == Sx2)) && ((Math.Abs(Cy2N) > Sy1N) || (Math.Abs(Cy2N) < Sy2N))) || (((Cx2 < Sx1) || (Cx2 > Sx2)) && ((Math.Abs(Cy2N) == Sy1N) || (Math.Abs(Cy2N) == Sy2N))))
        //{
        //    sum += 50;
        //}
        //if ((Cx2 > Sx1) && (Cx2 < Sx2) && (Math.Abs(Cy2N) > Sy1N) && (Math.Abs(Cy2N) < Sy2N))
        //{
        //    sum += 100;
        //}
        //
        //if (((Cx3 > Sx2) || (Cx3 < Sx1)) || ((Math.Abs(Cy3N) < Sy1N) || (Math.Abs(Cy3N) > Sy2N)))
        //{
        //    sum += 0;
        //}
        //if (((Cx3 == Sx1) || (Cx3 == Sx2)) && ((Math.Abs(Cy3N) == Sy1N) || (Math.Abs(Cy3N) == Sy2N)))
        //{
        //    sum += 25;
        //}
        //if ((((Cx3 == Sx1) || (Cx3 == Sx2)) && ((Math.Abs(Cy3N) > Sy1N) || (Math.Abs(Cy3N) < Sy2N))) || (((Cx3 < Sx1) || (Cx3 > Sx2)) && ((Math.Abs(Cy3N) == Sy1N) || (Math.Abs(Cy3N) == Sy2N))))
        //{
        //    sum += 50;
        //}
        //if ((Cx3 > Sx1) && (Cx3 < Sx2) && (Math.Abs(Cy3N) > Sy1N) && (Math.Abs(Cy3N) < Sy2N))
        //{
        //    sum += 100;
        //}
        Console.WriteLine("{0}%",sum);
    }
}

