﻿using System;

class BoolGenderCheck
{
    static void Main()
    {
        Console.Title = "Plamen Popov";
        bool isFemale = false;
        if (isFemale==true)
        {
            Console.WriteLine("Your gender is female.");
        }
        else
        {
            Console.WriteLine("Your gender is male.");
        }
    }
}

