﻿using System;

class UnicodeToSymbol
{
    static void Main()
    {
        Console.Title = "72th Unicode Character";
        char Unicode72 = '\u0048';      //char used to declare unicode symbol
        Console.WriteLine("The symbol that has unicode 72 is: {0}", Unicode72);
    }
}

