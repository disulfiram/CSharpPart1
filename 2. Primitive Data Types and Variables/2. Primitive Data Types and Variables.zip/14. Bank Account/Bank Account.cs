﻿using System;

class BankAccount
{
    static void Main()
    {
        Console.Title = "Bank Account Information";
        string FirstName;
        string MiddleName;
        string LastName;
        decimal Ballance;
        string BankName;
        string IBAN;
        string BIC;
        long CreditCard1;
        long CreditCard2;
        long CreditCard3;
    }
}
