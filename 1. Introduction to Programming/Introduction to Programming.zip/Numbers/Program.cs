﻿using System;

class Numbers
{
    static void Main()
    {
        Console.Title = "Numbers";
        Console.WriteLine("1, 101 and 1001");
    }
}