﻿using System;

class PowerOfTwo
{
    static void Main()
    {
        double value = Math.Pow(12345,2);
        Console.Title = "12345 squared";
        Console.WriteLine(value);
    }
}
