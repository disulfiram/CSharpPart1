﻿//Create console application that prints your first and last name.

using System;

class Introduction
{
    static void Main()
    {
        Console.Title = "Introduction";
        Console.WriteLine("My name is Plamen Popov");
    }
}