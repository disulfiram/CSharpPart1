﻿//Create a console application that calculates and prints the square of the number 12345.

using System;

class PowerOfTwo
{
    static void Main()
    {
        double value = Math.Pow(12345,2);
        Console.Title = "12345 squared";
        Console.WriteLine(value);
    }
}